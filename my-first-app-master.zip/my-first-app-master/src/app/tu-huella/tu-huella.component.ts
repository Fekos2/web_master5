import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tu-huella',
  templateUrl: './tu-huella.component.html',
  styleUrls: ['./tu-huella.component.scss']
})
export class TuHuellaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
