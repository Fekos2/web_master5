import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrarse',
  templateUrl: './registrarse.component.html',
  styleUrls: ['./registrarse.component.scss']
})


export class RegistrarseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  submitIngresar() {
    console.log("dsimsidm");
  }
}
