import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compensar',
  templateUrl: './compensar.component.html',
  styleUrls: ['./compensar.component.scss']
})
export class CompensarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
